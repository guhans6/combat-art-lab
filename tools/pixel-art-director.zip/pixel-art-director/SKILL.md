---
name: pixel-art-director
description: Construct or revise deliberate pixel art in editable Aseprite sources using a frozen visual brief, scoped drawing operations, visual inspection, and deterministic checks. Use for character likeness corrections, pixel-art reconstruction, controlled sprite iteration, or cross-model art comparisons. Not an image-filter or image-generation replacement.
---

# Pixel-art director

## Outcome

Deliver an editable native asset and evidence that the requested change improved
its intended appearance without altering protected content. Tool success, file
correctness, visual quality, and user approval are separate outcomes.

## 1. Establish the task

Read the repository's `AGENTS.md` and its required context first. Preserve existing
working changes. Identify the authoritative references, exact baseline source,
allowed region/layers, native canvas, palette policy, and requested deliverables.
Record unresolved assumptions rather than treating your earlier critique as fact.

Choose one mode:
- **Local correction:** copy the existing native asset; protect everything outside
  the authorized region. Read [face-likeness.md](references/face-likeness.md) for heads.
- **New reconstruction:** draw into new named layers from the approved visual brief;
  read [craft.md](references/craft.md). Do not substitute an imported flattened
  reference for authored construction.
- **Animation:** only after an approved static/key-pose checkpoint; read the animation
  section of [craft.md](references/craft.md). Keep it a separate evaluation task.

For cross-model comparison, read [benchmark.md](references/benchmark.md). The
bundled `assets/combat-art-lab-v03.json` is a specific starting profile, not a
universal sprite size or an automatic choice of the repository's newest asset.

**Complete when:** a task profile names exact inputs, priorities, locks, scope,
output paths, and a bounded pass budget. If native input is missing, do not claim
native-preserving editing from a screenshot; identify the blocked input.

## 2. Verify one drawing backend

Read [setup.md](references/setup.md) on first use or after a tool/version change.
Run `python3 scripts/doctor.py` relative to this skill directory. This inventories
binaries only; it does not certify MCP connectivity. Discover the actual runtime
tool schemas. Use [adapters.md](references/adapters.md) for backend differences.

Prefer the existing verified backend. For a new multi-agent experiment, the
recommended candidate is Pebbly's Aseprite AI Artist. Diivi's MCP or explicit
Aseprite CLI/Lua are alternatives, not additional servers to start concurrently.
Choose live or headless mode explicitly; do not switch modes to conceal a failed
connection. Do not modify a file on disk while a live editor owns that file.

Run the scratch-document smoke procedure in setup.md, including image delivery,
a one-pixel edit, transparency behavior, save/reopen, and protection checks.

**Complete when:** the selected agent can inspect the returned image AND pixel
coordinates, make the intended scratch edit, and verify the result. A `connected`
status alone is insufficient. Missing installation permissions are a blocker,
not permission to broaden machine access.

## 3. Freeze inputs and observations

Work in a new run directory. Copy the native baseline, its export, and references;
record hashes and actual tool/model versions. For the supplied project use
`scripts/prepare_run.py prepare` as documented in benchmark.md. Keep originals
unchanged, including uncommitted ones. Establish a hard editable mask and the
allowed native layers. Record the pre-edit native structure and layer pixels.

View the complete reference and baseline, then inspect relevant crops at native
size and integer nearest-neighbor zoom. For faces, annotate approximate visible
landmarks with confidence; do not infer exact source pixels from a compressed or
rescaled screenshot. Treat the approved scene/close-up as primary when a generated
cutout disagrees. Do not copy compositing halos into the sprite.

**Complete when:** `observations.md` separates visible differences, uncertain
interpretations, and the single next change hypothesis. Preserve a baseline preview.

## 4. Draw a bounded pass

For a reconstruction, establish silhouette and large planes before detail. For
a correction, retain existing good pixels and patch only the relevant clusters.
Use the native grid, existing material colors, explicit layer/frame targets,
and a scoped selection or write mask. Read back the patch region before writing.

Make one coherent revision per pass. Save a labeled checkpoint and its operations
or Lua source. Use native undo transactions when the backend supports them. Check
erase-versus-skip behavior before sending a text grid back to the editor.
Meaningful one-pixel facial marks are valid; do not run blanket speckle removal.

**Complete when:** the revised native source and PNG exist in the run directory,
the changed region is known, and the agent has looked at the rendered result.
A long list of successful drawing calls is not a completed visual pass.

## 5. Evaluate both correctness and appearance

Run `scripts/pixel_checks.py check` against the frozen export and mask for a local
correction. Make a review sheet with `scripts/pixel_checks.py preview`. Read the
resulting image. Check source hashes with `scripts/prepare_run.py verify-inputs`.

Also inspect native source: layer order/names/visibility/opacity/blend modes,
frames/timing/cel positions, palette data, and protected layer pixels. Reuse the
repository's existing native checker where applicable. A flattened PNG diff
cannot detect hidden-layer damage. Save, close/reopen a scratch output, and verify
that its fresh export matches the intended output. Never close unsaved user work.

Assess likeness, orientation, expression, silhouette, coherent clusters, and
readability at native size. Compare against the reference, not only against the
previous attempt. Do not convert an automated lint score into an art rating.

**Complete when:** protected content passes both PNG and native checks, and visual
observations state what improved and what remains uncertain. If worse, retain the
checkpoint for evidence but revert the working copy to the best prior candidate.

## 6. Stop and hand off

Stop when the budget is reached, the next change lacks visual evidence, or a
required capability is missing. Never expand canvas/palette/scope to rescue a
benchmark without recording a new task variant. Do not self-approve final art.

Deliver native source, construction/patch history, transparent PNG, native-size
and zoomed comparisons, exact tool/model identifiers, verification results,
remaining visual gaps, and the unchanged-input check. State what was not tested.
The user selects the artistic result; preserve all tested candidates.

Research and evidence limits: [research.md](references/research.md).
