# Face-first likeness correction

## Reference priority

In combat-art-lab, the approved close-up and full scene define identity and
rendering. The generated isolated cutout is a supporting construction reference.
The repository style guide explicitly warns about cutout edge artifacts. Use
the full scene to check head/body proportion; use the close-up to resolve
features. Where their drawings disagree, record the disagreement rather than
combining every detail into a more elaborate face.

Use the native asset named in the task. The user calls the current result v03;
older comparison graphics contain v01/v02 labels. Neither those labels nor a
file named "latest" should silently select the benchmark input.

## Diagnose before prescribing

Make a head crop of the reference and baseline. Record visible landmarks:
- top and widest sides of skull/hair; chin; near and far cheek;
- near/far eye centers, widths and visible heights; eyebrow direction;
- nose bridge/tip marks; mouth center/corners; ear location;
- fringe openings, tie location, rear-hair outline and overlap with ear.

Mark estimated landmarks as estimated. Compare ratios in the face region, not
raw source-image distances across different resolutions. A photographic anatomy
ratio is not automatically the right rule for this stylized drawing.

For each discrepancy write: **observation → confidence → likely cause → small
test → expected visible result**. Example structure (not a diagnosis of v03):
"Far eye is difficult to distinguish at 1x; high confidence. It may be merged
with fringe rather than spaced incorrectly. Test separating those clusters before
moving the eye center. Expected: same head turn, both eyes still readable."

Do not start with "move eyes closer" unless the actual comparison supports it.
The v03 construction uses pupil coordinates around (64,21) and (70,21), but those
are historical construction choices, not target anatomy or verified optimum.

## Work in dependency order

First verify skull/face orientation and cheek-to-chin proportions. Next establish
the near/far eye relationship and eyeline slope; then expression, brow/mouth
asymmetry and fringe overlap. Do not compensate for a wrong head angle by making
the far eye an equally large frontal eye. Keep the gaze coherent without demanding
identical iris offsets in eyes of different widths.

Keep the mouth and nose economical. At this scale, one pixel can change a smile,
age impression or head angle. Test small alternate clusters in separate working
copies; avoid adding details merely because they exist in the large concept.
Prefer a readable, subtly quirky expression to symmetric beautification.

Check rear-hair volume, the tie and major fringe masses against the reference.
Preserve deliberate messiness, not individual high-resolution strands. Hair and
skin should remain separate editable sources. Keep the ear partially occluded
where the reference shows that overlap; do not force a fully detailed ear.

## Exact v03 protection profile

Derived from `assets/source/standing-v03/edit-head.lua`, inspected 2026-10-26:
- canvas 128x192; coordinates zero-based;
- editable x34..79 and y2..30 inclusive;
- protect the neck notch x57..65 at y29..30;
- only `01-hair-back`, `05-skin-face`, `10-hair-front`, `11-face-features`;
- the other eight layers and all pixels outside the mask remain unchanged.

These boundaries are meaningful only for this exact native asset. The skin layer
also contains protected material; selecting the entire skin layer is not safe.
The bundled JSON expresses the same geometry as half-open rectangles. Re-verify
it against the actual source before work. If the lock blocks a proposed redesign,
record that tradeoff instead of extending the mask inside a comparison run.

## Acceptance evidence

Provide baseline/candidate/reference heads at comparable displayed sizes, plus
full native-scale sprites. Report the observed changes, not "more accurate" as
an unmeasured fact. Check zero protected-pixel changes, unchanged native structure
and protected layers, and a fresh reopen/export. Ask the user to judge identity
and expression only after showing the actual candidate; do not manufacture approval.
